<script setup>
import LoginForm from "@/layouts/LoginForm.vue";
</script>

<template>
	<section>
		<div class="container">
			<LoginForm />
		</div>
	</section>
</template>
