<script setup>
import TheCart from "@/layouts/TheCart/TheCart.vue";
</script>

<template>
	<TheCart />
</template>
