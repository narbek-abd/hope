<script setup>
import RegisterForm from "@/layouts/RegisterForm.vue";
</script>

<template>
	<section>
		<div class="container">
			<RegisterForm />
		</div>
	</section>
</template>
