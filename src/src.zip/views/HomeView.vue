<script setup>
import FeaturedProducts from "@/layouts/FeaturedProducts.vue";
import LatestProducts from "@/layouts/LatestProducts.vue";
</script>

<template>
  <FeaturedProducts />
  <LatestProducts />
</template>
