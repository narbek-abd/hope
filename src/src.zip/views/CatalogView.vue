<script setup>
import ProductsList from "@/layouts/ProductsList/ProductsList.vue";
import BreadCrumbs from "@/components/BreadCrumbs.vue";
</script>

<template>
  <div class="container">
    <BreadCrumbs />
  </div>

  <ProductsList />
</template>
